from fractions import Fraction
from functools import lru_cache
import sys, time
GMAX=int(sys.argv[1]) if len(sys.argv)>1 else 23
Amax=GMAX//3+2
c=[Fraction(0) for _ in range(Amax+1)]
c[1]=Fraction(5,6)
for r in range(2,Amax+1):
    s=Fraction(0)
    for i in range(1,r-1):
        s += i*(r-1-i)*c[i]*c[r-1-i]
    c[r]=6*(r-1)*c[r-1]+Fraction(6,r)*s

def partitions(n, max_part=None):
    if max_part is None or max_part>n: max_part=n
    if n==0:
        yield []
    else:
        for first in range(max_part,0,-1):
            for rest in partitions(n-first, min(first,n-first) if n-first>0 else 0):
                yield [first]+rest

def b_for_part(mu,a):
    q=[m+1 for m in mu]
    D=[Fraction(0)]*(a+1)
    for j in range(1,a+1):
        D[j]=sum(Fraction(qq,1)-Fraction(1,qq**j) for qq in q)
    b=[Fraction(0)]*(a+1); b[0]=1
    for r in range(1,a+1):
        s=Fraction(0)
        for j in range(1,r+1):
            s += j*c[j]*D[j]*b[r-j]
        b[r] = -s/Fraction(r,1)
    return b[a]
start=time.time()
for g in range(2,GMAX+1):
    if g%3 not in (0,2): continue
    a=g//3+1 # floor works for residues? floor(g/3)+1
    M=2*g-2
    cnt=0; maxb=None; arg=None
    for mu in partitions(M):
        val=b_for_part(mu,a)
        cnt+=1
        if val>=0:
            print('NONNEG',g,a,mu,val); sys.exit(1)
        if maxb is None or val>maxb:
            maxb=val; arg=tuple(mu)
    print('g',g,'a',a,'M',M,'parts',cnt,'max_arg',arg,'max',float(maxb), flush=True)
print('all small negative elapsed', time.time()-start)
