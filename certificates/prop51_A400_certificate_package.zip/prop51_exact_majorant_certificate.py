from fractions import Fraction
import time, sys
Amax=int(sys.argv[1]) if len(sys.argv)>1 else 60
c=[Fraction(0) for _ in range(Amax+1)]
c[1]=Fraction(5,6)
for r in range(2,Amax+1):
    s=Fraction(0)
    for i in range(1,r-1):
        s += i*(r-1-i)*c[i]*c[r-1-i]
    c[r]=6*(r-1)*c[r-1]+Fraction(6,r)*s
R=[[Fraction(0) for _ in range(Amax+1)] for __ in range(Amax+1)]
for r in range(2,Amax+1):
    cr=c[r]
    for j in range(1,r):
        R[j][r]=c[j]*c[r-j]/cr
start=time.time(); maxU=None; maxPair=None; count=0
Nmin=6*9-7; Nmax=12*Amax-8
for N in range(Nmin,Nmax+1):
    X=[Fraction(0)]*(Amax+1); Y=[Fraction(0)]*(Amax+1)
    X[1]=Fraction(-1); Y[1]=Fraction(1)
    for r in range(2,Amax+1):
        sx=Fraction(0); sy=Fraction(0)
        for j in range(1,r):
            rr=R[j][r]
            sx += j*rr*X[r-j]
            sy += j*rr*Y[r-j]
        X[r]=Fraction(-1)-Fraction(N,r)*sx
        Y[r]=Fraction(1)+Fraction(N,2*r)*sy
    # determine a values whose rectangle includes N
    a_lo=max(9, (N+8 + 12 -1)//12)  # N <=12a-8 => a >= (N+8)/12
    a_hi=min(Amax, (N+7)//6)         # N >=6a-7 => a <= (N+7)/6
    for a in range(a_lo,a_hi+1):
        U=X[a]+Fraction(1,2**(a+1))*Y[a]
        for k in range(1,a):
            if X[k]>0:
                U += Fraction(N,2)*R[k][a]*Fraction(1,2**(a-k))*X[k]*Y[a-k]
        count += 1
        if U>=0:
            print('NONNEG',a,N,float(U),U); sys.exit(1)
        if maxU is None or U>maxU:
            maxU=U; maxPair=(a,N)
    if N%50==0:
        print('N',N,'elapsed',time.time()-start,'max',maxPair,float(maxU), flush=True)
print('all neg',count,'max',maxPair,maxU,float(maxU),'elapsed',time.time()-start)
