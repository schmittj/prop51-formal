from flint import arb, ctx
import sys, time, os, multiprocessing as mp
if len(sys.argv)<4:
    print('usage: Amax bits Nlo Nhi [nproc]')
    sys.exit(2)
Amax=int(sys.argv[1]); bits=int(sys.argv[2]); Nlo=int(sys.argv[3]); Nhi=int(sys.argv[4]); nproc=int(sys.argv[5]) if len(sys.argv)>5 else min(16, os.cpu_count() or 1)
ctx.prec=bits
zero=arb(0); A=Amax
start=time.time()
d=[arb(0) for _ in range(A+1)]
d[1]=arb(5)/arb(36)
for r in range(2,A+1):
    s=arb(0); invbin=arb(1)/arb(r-1)
    for i in range(1,r-1):
        if i>1: invbin *= arb(i)/arb(r-i)
        s += d[i]*d[r-1-i]*invbin
    d[r]=d[r-1]+s/arb(r)
R=[[arb(0) for _ in range(A+1)] for __ in range(A+1)]
for r in range(2,A+1):
    invcomb=arb(1); factor=arb(1)/(arb(r-1)*d[r])
    for j in range(1,r):
        if j>1: invcomb *= arb(j-1)/arb(r-j)
        R[j][r]=d[j]*d[r-j]*factor*invcomb
pow2=[arb(1)]*(A+2)
for n in range(1,A+2): pow2[n]=pow2[n-1]/arb(2)
def ub(x): return x.upper()
def lb(x): return x.lower()
def worker(rng):
    lo,hi=rng; ctx.prec=bits
    max_upper=None; max_pair=None; count=0; undecided=0
    for N in range(lo,hi+1):
        rmax=min(A,(N+7)//6)
        X=[arb(0)]*(rmax+1); Y=[arb(0)]*(rmax+1)
        if rmax>=1:
            X[1]=arb(-1); Y[1]=arb(1)
        for r in range(2,rmax+1):
            sx=arb(0); sy=arb(0)
            for j in range(1,r):
                rr=R[j][r]
                sx += arb(j)*rr*X[r-j]
                sy += arb(j)*rr*Y[r-j]
            X[r]=arb(-1)-arb(N)/arb(r)*sx
            Y[r]=arb(1)+arb(N)/(arb(2)*arb(r))*sy
        a_lo=max(9,(N+19)//12); a_hi=rmax
        for a in range(a_lo,a_hi+1):
            Uu=ub(X[a])+pow2[a+1]*ub(Y[a])
            for k in range(1,a):
                xku=ub(X[k])
                if xku>zero:
                    if not (lb(X[k])>zero): undecided+=1
                    Uu += (arb(N)/arb(2))*ub(R[k][a])*pow2[a-k]*xku*ub(Y[a-k])
            count+=1
            if not (Uu<zero):
                return False,count,(a,N),str(Uu),undecided,lo,hi
            if max_upper is None or Uu>max_upper:
                max_upper=Uu; max_pair=(a,N)
    return True,count,max_pair,str(max_upper),undecided,lo,hi
if __name__=='__main__':
    Nlo=max(Nlo,6*9-7); Nhi=min(Nhi,12*A-8)
    length=Nhi-Nlo+1
    # use many small chunks for load balancing
    nchunks=max(nproc*4,1)
    chunks=[]
    for i in range(nchunks):
        lo=Nlo+i*length//nchunks; hi=Nlo+(i+1)*length//nchunks-1
        if lo<=hi: chunks.append((lo,hi))
    print('RANGE_START Amax',A,'bits',bits,'Nrange',(Nlo,Nhi),'nproc',nproc,'chunks',len(chunks),'precompute_elapsed',time.time()-start, flush=True)
    with mp.get_context('fork').Pool(processes=nproc) as pool:
        results=[]
        for res in pool.imap_unordered(worker,chunks):
            print('chunk',res[5],res[6],'ok',res[0],'count',res[1],'max_pair',res[2],'max_upper',res[3],'undecided',res[4], flush=True)
            results.append(res)
            if not res[0]:
                pool.terminate(); break
    ok=all(r[0] for r in results) and len(results)==len(chunks)
    total=sum(r[1] for r in results)
    print('RANGE_DONE ok',ok,'total_count',total,'Amax',A,'bits',bits,'Nrange',(Nlo,Nhi),'elapsed',time.time()-start)
